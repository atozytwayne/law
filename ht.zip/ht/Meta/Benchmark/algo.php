<?php
error_reporting(0);
date_default_timezone_set("Asia/Jakarta");

function check_carrier($phone)
{
	$key = '2829d1c532dea3a97edeb498e9275f69';
	$ch  = curl_init('http://apilayer.net/api/validate?access_key=' . $key . '&number=' . $phone . '');
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$json = curl_exec($ch);
	curl_close($ch);
	$Result = json_decode($json, true);
	return $Result;
}


function getUserIP()
{
	$client  = @$_SERVER['HTTP_CLIENT_IP'];
	$forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
	$remote  = $_SERVER['REMOTE_ADDR'];

	if (filter_var($client, FILTER_VALIDATE_IP))
	{
		$ip      = $client;
	}
	elseif (filter_var($forward, FILTER_VALIDATE_IP))
	{
		$ip      = $forward;
	}
	else
	{
		$ip      = $remote;
	}

	return $ip;
}

function tulis_file($nama, $isi)
{
	$click = fopen("$nama", "a");
	fwrite($click, "$isi" . "\n");
	fclose($click);
}

$ip2 = getUserIP();
if ($ip2 == "127.0.0.1")
{
	$ip2 = "";
}

$ip  = getUserIP();
if ($ip == "127.0.0.1")
{
	$ip  = "";
}
function get_ip1($ip2)
{
	$url = "http://www.geoplugin.net/json.gp?ip=" . $ip2;
	$ch  = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4);
	$resp = curl_exec($ch);
	curl_close($ch);
	return $resp;
}

function get_ip2($ip)
{
	$url = 'http://extreme-ip-lookup.com/json/' . $ip;
	$ch  = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4);
	$resp = curl_exec($ch);
	curl_close($ch);
	return $resp;
}

$details     = get_ip1($ip2);
$details     = json_decode($details, true);
$countryname = $details['geoplugin_countryName'];
$countrycode = $details['geoplugin_countryCode'];
$cn          = $countryname;
$cid         = $countrycode;
$continent   = $details['geoplugin_continentName'];
$citykota    = $details['geoplugin_city'];
$regioncity  = $details['geoplugin_region'];
$timezone    = $details['geoplugin_timezone'];
$kurenci     = $details['geoplugin_currencySymbol_UTF8'];

if ($countryname == "")
{
	$details     = get_ip2($ip2);
	$details     = json_decode($details, true);
	$countryname = $details['country'];
	$countrycode = $details['countryCode'];
	$cn          = $countryname;
	$cid         = $countrycode;
	$continent   = $details['continent'];
	$citykota    = $details['city'];
}
