<?php 
  $tele_chat_id = "5771100859";
  $tele_token = "6092965426:AAEGmrB5UnbV25ThoOtExAHL6WWCMYzQui8";
  ?>